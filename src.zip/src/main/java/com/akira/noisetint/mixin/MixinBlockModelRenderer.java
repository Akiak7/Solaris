package com.akira.noisetint.mixin;

import net.minecraft.block.Block;
import net.minecraft.block.BlockLeaves;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.renderer.BlockModelRenderer;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.block.model.IBakedModel;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

@Mixin(BlockModelRenderer.class)
public abstract class MixinBlockModelRenderer {

    @Unique private static final Logger NB_LOG = LogManager.getLogger("NoisyBiomes");
    @Unique private static boolean NB_LOGGED = false;
    @Unique private static final ThreadLocal<IBlockState> NB$STATE = new ThreadLocal<>();

    // ----- HEAD hooks on all three entry points (MCP + SRG fallbacks)
    @Inject(method = {
            "renderModel",          // MCP
            "renderModelFlat",      // MCP
            "renderModelSmooth",    // MCP
            "func_187493_a",        // SRG: renderModel
            "func_187498_b",        // SRG: renderModelFlat
            "func_187497_c"         // SRG: renderModelSmooth
    }, at = @At("HEAD"), require = 0)
    private void nb$head(IBlockAccess world, IBakedModel model, IBlockState state, BlockPos pos,
                         BufferBuilder buf, boolean checkSides, long rand, CallbackInfo ci) {
        NB$STATE.set(state);
        if (!NB_LOGGED) { NB_LOG.info("Renderer mixin ACTIVE"); NB_LOGGED = true; }
    }

    // ----- RETURN hooks to clear thread-local
    @Inject(method = {
            "renderModel", "renderModelFlat", "renderModelSmooth",
            "func_187493_a", "func_187498_b", "func_187497_c"
    }, at = @At("RETURN"), require = 0)
    private void nb$tail(IBlockAccess world, IBakedModel model, IBlockState state, BlockPos pos,
                         BufferBuilder buf, boolean checkSides, long rand, CallbackInfo ci) {
        NB$STATE.remove();
    }

    // ----- Force leaves quads with tintIndex==-1 to behave as tintIndex==0
    @Redirect(method = {
            "renderModel", "renderModelFlat", "renderModelSmooth",
            "func_187493_a", "func_187498_b", "func_187497_c"
    }, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/block/model/BakedQuad;getTintIndex()I"), require = 0)
    private int nb$forceLeafTint(BakedQuad quad) {
        int idx = quad.getTintIndex();
        if (idx != -1) return idx;

        IBlockState st = NB$STATE.get();
        if (st == null) return -1;
        Block b = st.getBlock();
        boolean isLeaves = (b instanceof BlockLeaves) || (st.getMaterial() == Material.LEAVES);
        return isLeaves ? 0 : -1;
    }
}
